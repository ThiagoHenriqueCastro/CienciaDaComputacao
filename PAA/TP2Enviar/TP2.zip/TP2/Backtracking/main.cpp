#include <iostream>
#include <iomanip>

using namespace std;

#define N 8

void permute(string s, int b, int e)
{
    // Caso base
    if (b == e)
        cout << s << endl;
    else
    {
        // Sao feitas "e" permutações
        for (int i = b; i <= e; i++)
        {
            swap(s[b], s[i]);

            permute(s, b + 1, e);

            // backtracking
            swap(s[b], s[i]);
        }
    }
}

// Checa se uma posicao do tabuleiro é valida
// Se esta dentro do tabuleiro e nao foi visitada
bool isPositionSafe(int x, int y, int board[N][N])
{
    return (x >= 0 && x < N && y >= 0 && y < N && board[x][y] == -1);
}

// Printa o tabuleiro
void showBoard(int board[N][N])
{
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
            cout << " " << setw(2) << board[i][j] << " ";
        cout << endl;
    }
}

int horseTour_(int x, int y, int n_move, int board[N][N], int movesX[8], int movesY[8])
{
    // index e as proximas posicoes
    int i, nextX, nextY;

    // Caso base, numero de movimentos é o numero total de posicoes
    if (n_move == N * N)
        return 1;

    // Testa todas as posicoes possiveis partindo do ponto atual

    for (i = 0; i < 8; i++)
    {
        // As proximas posicoes sao, o ponto atual + o movimento
        nextX = x + movesX[i];
        nextY = y + movesY[i];
        // Checa se essa nova posicao é valida
        if (isPositionSafe(nextX, nextY, board))
        {
            // salva nela qual o numero dessa movimentacao, ou seja, quamdo ela foi atingida
            board[nextX][nextY] = n_move;
            // avanca recursivamente para o proximo movimento
            // Ele percorre recursivamente todos os movimentos possiveis a partir de todas as casas
            // Caso nao consiga ir para todas, ele retorna zero e fazemos o backtracking
            if (horseTour_(nextX, nextY, n_move + 1, board, movesX, movesY) == 1)
                return 1;
            // marcamos a posicao como -1, para ser atingida por outros movimentos
            else
                board[nextX][nextY] = -1;
        }
    }

    return 0;
}

void horseTour()
{
    // Inicializa o tabuleiro com -1 em todas as posicoes
    int board[N][N];
    memset(board, -1, sizeof(board));

    // Monta todas as posicoes possiveis a partir de uma posicao do tabuleiro
    int movesX[8] = {2, 1, -1, -2, -2, -1, 1, 2};
    int movesY[8] = {1, 2, 2, 1, -1, -2, -2, -1};

    // Inicio do percurso do cavalo na posicao 0 0
    board[0][0] = 0;

    // percorro recursivamente o tabuleiro
    if (horseTour_(0, 0, 1, board, movesX, movesY) == 0)
    {
        cout << "Problema sem solução";
        return;
    }
    else
        showBoard(board);

    return;
}

int main()
{
    string strSet = "ABC";

    int n = strSet.size();
    cout << "String Permutations: " << endl;
    permute(strSet, 0, n - 1);
    cout << endl
         << endl;
    cout << "Knight Tour: " << endl;
    horseTour();
}