#include <stdio.h>
#include <stdlib.h>

int main()
{
    float lado = 7.0;
    float perimetro = lado * 4;

    printf("O perimetro do quadrado de lado %.2f é igual a %.2f", lado, perimetro);
}