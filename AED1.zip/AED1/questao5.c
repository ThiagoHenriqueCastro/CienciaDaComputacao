#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float raio = 5.0;
    float perimetro = 2 * M_PI * raio;

    printf("O perimetro do circulo de raio %.2f é igual a %.2f", raio, perimetro);
}