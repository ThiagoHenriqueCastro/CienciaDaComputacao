#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float lado = 10.0;
    float area = pow(lado, 2);

    printf("A area do quadrado de lado %.2f é igual a %.2f", lado, area);
}